package com.example.contentproviderdemo1;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.UserDictionary;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    List<String> list = new ArrayList<>();
    ArrayAdapter<String> adapter;
    ListView listView;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        insert();

        listView = findViewById(R.id.list_view);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);
        read();

        button = findViewById(R.id.button1);
        button.setOnClickListener(v -> {
            Intent intent = new Intent(this,MainActivity2.class);
            startActivity(intent);
        });
    }

    public void insert() {
        Uri uri = null;
        try {
            ContentValues newValues = new ContentValues();
            newValues.put(UserDictionary.Words.APP_ID, "example.user");
            newValues.put(UserDictionary.Words.LOCALE, "en_US");
            newValues.put(UserDictionary.Words.WORD, "insert");
            newValues.put(UserDictionary.Words.FREQUENCY, "100");
            Log.d("contenturi",UserDictionary.Words.CONTENT_URI.toString());
            uri = getContentResolver().insert(UserDictionary.Words.CONTENT_URI, newValues);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @SuppressLint("Recycle")
    public void read() {
        Cursor cursor;
        try {
            String[] mProjection = {
                    UserDictionary.Words._ID,
                    // Contract class constant for the _ID column name
                    UserDictionary.Words.WORD,
                    // Contract class constant for the word column name
                    UserDictionary.Words.LOCALE
                    // Contract class constant for the locale column name
            };
            cursor = getContentResolver().query(UserDictionary.Words.CONTENT_URI,
                    mProjection, null, null, null);
            Log.d("create", cursor.getCount() + "");
            if (cursor!=null){
                int ID = cursor.getColumnIndex(UserDictionary.Words._ID);
                int Word = cursor.getColumnIndex(UserDictionary.Words.WORD);
                int Local = cursor.getColumnIndex(UserDictionary.Words.LOCALE);
                while (cursor.moveToNext()) {
                    String id = cursor.getString(ID);
                    String word = cursor.getString(Word);
                    String local = cursor.getString(Local);
                    list.add(id + " " + word + " " + local);
                }
            }
            adapter.notifyDataSetChanged();
            cursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}