package com.example.contentproviderdemo1;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.ContentProviderOperation;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MainActivity2 extends AppCompatActivity {
    ListView listView;
    List<String> list = new ArrayList<>();
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        listView = findViewById(R.id.list_view1);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);

        String[] array = {Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS};
        registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
            for (Map.Entry<String, Boolean> map : result.entrySet()) {
                if (map.getKey().equals(Manifest.permission.READ_CONTACTS) && map.getValue()) {
                    Log.d("contacts_read", map.getKey() + " permission");
                    read();
                } else if (map.getKey().equals(Manifest.permission.WRITE_CONTACTS) && map.getValue()) {
                    Log.d("contacts_write", map.getKey() + " permission");
                    insert();
                } else {
                    Log.d("contacts", map.getKey() + " denied");
                }
            }
        }).launch(array);
    }

    public void insert() {
        try {
            /* 往 raw_contacts 中添加数据，并获取添加的id号*/
            Uri uri = Uri.parse("content://com.android.contacts/raw_contacts");
            ContentResolver resolver = getContentResolver();
            ContentValues values = new ContentValues();
            // 首先向RawContacts.CONTENT_URI执行一个空值插入，目的是获取系统返回的rawContactId
            long contactId = ContentUris.parseId(resolver.insert(ContactsContract.RawContacts.CONTENT_URI,
                    values));
            Log.d("contactId",contactId+"");

            // 添加姓名
            uri = Uri.parse("content://com.android.contacts/data");
            values.put("raw_contact_id", contactId);
            values.put("mimetype", "vnd.android.cursor.item/name");
            values.put("data2", "JIANG");
            resolver.insert(ContactsContract.Data.CONTENT_URI, values);
            values.clear();

            // 添加电话
            values.put("raw_contact_id", contactId);
            values.put("mimetype", "vnd.android.cursor.item/phone_v2");
            values.put("data2", "2");
            values.put("data1", "787879");
            resolver.insert(ContactsContract.Data.CONTENT_URI, values);
            values.clear();

            // 添加家庭电话号码，其它的操作， 比如家庭email 等， 都类似，就是,data2数值不同罢了！
            /*
            values.put("raw_contact_id", contactId);
            values.put("mimetype", "vnd.android.cursor.item/phone_v2");
            values.put("data2", "1");
            values.put("data1", "homePhone");
            resolver.insert(uri, values);
            values.clear();

             */

            // 添加Email
            /*
            values.put("raw_contact_id", contactId);
            values.put("mimetype", "vnd.android.cursor.item/email_v2");
            values.put("data2", "2");
            values.put("data1", "email");
            resolver.insert(uri, values);

             */

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void read() {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    null, null, null, null);
            //content://com.android.contacts/data/phones
            if (cursor != null) {
                int name = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                int number = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                while (cursor.moveToNext()) {
                    String display_name = cursor.getString(name);
                    String phone_numer = cursor.getString(number);
                    list.add(display_name + "\n" + phone_numer);
                }
                adapter.notifyDataSetChanged();
                cursor.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}











